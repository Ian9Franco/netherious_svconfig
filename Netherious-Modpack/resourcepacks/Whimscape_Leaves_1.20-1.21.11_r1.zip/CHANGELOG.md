### **Whimscape Leaves 1.20-1.21.11_r1** (2026 Jan 31)

- Added .mcmeta files for all textures to handle mipmaps in 1.21.11+

________________________________________________________________

### **Whimscape Leaves 1.20-1.21.10_r1** (2025 Oct 18)

- Changed pack.mcmeta to include format 15, consolidating 1.20-1.20.1 support into new releases

________________________________________________________________

### **Whimscape Leaves 1.20.2-1.21.5_r1** (2025 Apr 12)

- Added cherry leaves variant texture
- Changed cherry leaves texture slightly

________________________________________________________________

### **Whimscape Leaves 1.20.2-1.21.3_r1** (2024 Oct 26)

- Added pale oak leaves
- Changed acacia leaves' darkest shade slightly

________________________________________________________________

### **Whimscape Leaves 1.20.2-1.20.4_r1** (2024 Mar 27)

- Changed pack_format to 18, added supported_formats

________________________________________________________________

### **Whimscape Leaves 1.20_r1** (2023 Jun 7)

- Added cherry leaves
- Changed azalea flower colors slightly
- Changed pack_format to 15

________________________________________________________________

### **Whimscape Leaves 1.19.3_r2** (2023 Feb 19)

- Changed azalea blocks slightly
- Changed pack.png: small tweak

________________________________________________________________

### **Whimscape Leaves 1.19.3_r1** (2022 Dec 7)

- Changed pack_format to 12

________________________________________________________________

### **Whimscape Leaves 1.19_r2** (2023 Feb 19)

- Backported changes from 1.19.3_r2

________________________________________________________________

### **Whimscape Leaves 1.19_r1** (2022 Oct 1)

- Initial release