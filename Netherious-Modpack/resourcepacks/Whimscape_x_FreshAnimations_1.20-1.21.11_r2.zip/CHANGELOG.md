### **Whimscape x Fresh Animations 1.20-1.21.11_r2** (2026 Jan 14)

- fixed cows being mostly invisible when using Forge 1.20.1 and Oculus

________________________________________________________________

### **Whimscape x Fresh Animations 1.20-1.21.11_r1** (2025 Dec 19)

- changed horse saddle textures
- removed horse armor textures

________________________________________________________________

### **Whimscape x Fresh Animations 1.20-1.21.10_r1** (2025 Nov 26)

- fixed mooshroom blinks (FA 1.10.2)
- fixed rule_index handling for bee, chickens, cows, mooshroom, pigs (FA 1.10.2)

________________________________________________________________

### **Whimscape x Fresh Animations 1.20-1.21.8_r1** (2025 Oct 28)

> **NOTE**: Use EMF for game versions 1.20-1.21.2. OptiFine will not work.

- allay
    - changed texture to the one in Whimscape 1.20.2-1.21.10_r1
- axolotl
    - fixed texture: eye position
- bat
    - added texture
- bee
    - added bee.properties
    - changed bee_baby.properties
    - changed models to depend on FA for animations
- bogged
    - added model
    - fixed texture
    - removed model parts
- cave spider
    - added model
    - fixed texture
    - removed model parts and their texture
- chicken
    - added models
    - added chicken.properties & chicken_baby.properties
    - removed model parts
- cold chicken
    - added model
- cold cow
    - changed model to depend on FA for animations (baked in some animations from FA:Details)
    - changed texture: added separate tail
- cold pig
    - added cold_pig_baby model
    - added cold_pig_baby.properties
    - changed model to depend on FA for animations (baked in some animations from FA:Details)
    - changed texture: separated eyes from face
- cow
    - added cow.properties & cow_baby.properties
    - changed models to depend on FA for animations (baked in some animations from FA:Details)
    - changed texture: added separate tail
- creeper
    - added model
    - fixed texture
    - removed model parts
- dolphin
    - added model from FA 1.10.1 and corrected right fin texture mirroring
- donkey
    - fixed texture: flipped saddlebags
- drowned
    - added textures
- elder guardian
    - added texture
- enderman
    - changed texture: tweaked jaw
- endermite
    - added textures
- evoker
    - added model
    - changed texture: separated eyes from face, lengthened eyebrows
    - removed model parts
- glow squid
    - added texture
- goat
    - removed goat_baby.properties
- guardian
    - added model from FA 1.10.1 with an added eye glint
    - added texture
- happy ghast
    - added texture
- hoglin
    - added model
    - fixed textures
    - removed model part and its texture
- horse
    - added armor textures
- husk
    - added texture
- illusioner
    - added model
    - changed texture: separated eyes from face
    - removed model part
- magma cube
    - fixed texture
- mooshroom
    - changed models to depend on FA for animations
    - changed textures: added separate tail
    - changed mooshroom.properties & mooshroom_baby.properties
- mule
    - fixed texture: flipped saddlebags
- parrot
    - fixed textures: eyes
- pig
    - added pig.properties
    - fixed pig_saddle texture dimensions
    - changed model to depend on FA for animations (baked in some animations from FA:Details)
    - changed texture: separated eyes from face
    - changed pig_baby.properties
- piglins
    - changed textures: separated eyes from faces
- pillager
    - added model
    - changed texture: separated eyes from face, lengthened eyebrows
    - removed model parts
- sheep
    - added models
    - fixed texture
    - removed model parts
- snow golem
    - added texture
- spider
    - added model
    - fixed texture
    - removed model parts and their texture
- squid
    - added texture
- strider
    - fixed texture: hair position
- villager
    - added models
    - added villager.properties & villager_baby.properties
    - changed texture: separated eyes from face
    - removed model parts
- vindicator
    - added model
    - changed texture: separated eyes from face, lengthened eyebrows
    - removed model parts
- wandering trader
    - added model
    - fixed texture
    - removed model parts
- warm cow
    - added model
    - changed texture: added separate tail and tweaked horns
- warm pig
    - changed texture: separated eyes from face
- witch
    - added model
    - changed texture: separated eyes and mouth from face, tweaked collar of robe
    - removed model parts
- wolf
    - added model
    - changed textures: separated eyes from faces
    - removed model part
- zoglin
    - added model
    - fixed texture
    - removed model part and its texture
- zombie
    - added texture
- zombie villager
    - added model
    - removed model parts
- removed overlay folders

________________________________________________________________

### **Whimscape x Fresh Animations 1.20.2-1.21.5_r1** (2025 May 18)

- fixed chickens, cows and pigs and their variants for 1.21.5 (FA 1.9.4+)
- fixed babies of cows, goats, mooshrooms and pigs reverting to default models under certain conditions with OptiFine (FA 1.9.3+)
- fixed bee babies not using the Whimscape model (FA 1.9.3+)
- fixed saddles
- fixed sheep leg mirroring
- changed cow texture slightly

________________________________________________________________

### **Whimscape x Fresh Animations 1.20.2-1.21.4_r2** (2025 Apr 20)

- added pig model matching the new one in Whimscape 1.20.2-1.21.5_r2
- changed pig texture for the new model
- changed chicken textures

________________________________________________________________

### **Whimscape x Fresh Animations 1.20.2-1.21.4_r1** (2024 Dec 19)

- fixed mooshroom baby for 1.21.2 / FA 1.9.3

________________________________________________________________

### **Whimscape x Fresh Animations 1.20.2-1.21.3_r1** (2024 Oct 28)

- fixed mooshrooms

________________________________________________________________

### **Whimscape x Fresh Animations 1.20.2-1.21_r1** (2024 Jul 10)

- added bogged with custom mushroom parts
- fixed wolves
- fixed colored shulkers
- changed vindicator pants color

________________________________________________________________

### **Whimscape x Fresh Animations 1.20.2-1.20.4_r1** (2024 Mar 14)

- changed pack_format to 18, added supported_formats to pack.mcmeta

________________________________________________________________

### **Whimscape x Fresh Animations 1.20-1.20.1_r1** (2024 Mar 14)

- fixed allay, bee, creeper, goat, shulker and sniffer for FA 1.9
- fixed z-fighting in hoglin and zoglin manes
- changed pack_format to 15

________________________________________________________________

### **Whimscape x Fresh Animations 1.19.4_r1** (2024 Mar 14)

- fixed allay, bee, creeper, goat and shulker for FA 1.9
- fixed z-fighting in hoglin and zoglin manes
- changed pack_format to 13

________________________________________________________________

### **Whimscape x Fresh Animations 1.19.3_r1** (2023 Jun 09)

- fixed vex textures for the new model
- changed horse_creamy colors slightly
- changed pack_format to 12

________________________________________________________________

### **Whimscape x Fresh Animations 1.19_r1** (2023 Feb 10)
- initial release